请先完整解压 ZIP，再用 Chrome 或 Edge 打开 tang-v3.html。
不要在聊天附件预览器或压缩包预览器内运行。
此 HTML 内嵌图片和脚本，不需要安装依赖。
